(ns sample2.core-test
  (:use [sample2.core] :reload-all)
  (:use [clojure.test]))

(deftest replace-me ;; FIXME: write
  (is false))
