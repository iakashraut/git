(ns lein-test-reload-bug.b-protocol)

(defprotocol B
  (b [this]))
