"don't include me in the uberjar!"
