(defproject nomnomnom "0.5.0-SNAPSHOT"
  :dependencies [[org.clojure/clojure "1.8.0"]
                 [janino "2.5.15"]]
  :aot :all
  :uberjar-exclusions [#"DUMMY"])
