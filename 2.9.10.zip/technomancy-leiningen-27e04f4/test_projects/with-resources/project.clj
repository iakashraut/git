(defproject project-with-resources "0.5.0-SNAPSHOT"
  :dependencies [[org.clojure/clojure "1.3.0"]
                 [janino "2.5.15"]]

  :resource-paths ["resources"])
