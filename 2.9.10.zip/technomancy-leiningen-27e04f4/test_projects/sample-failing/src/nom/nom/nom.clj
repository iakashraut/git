(ns nom.nom.nom
  (:gen-class))

failure-expected-here-dont-freak-out

This noming squirrel will cause compilation of this file to fail.

 ,;;:;,
   ;;;;;
  ,:;;:;    ,'=.
  ;:;:;' .=" ,'_\
  ':;:;,/  ,__:=@
   ';;:;  =./)_
     `"=\_  )_"`
          ``'"
