(ns more-gen-classes.bar
  (:gen-class))
