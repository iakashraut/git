(ns more-gen-classes.foo
  (:gen-class))
