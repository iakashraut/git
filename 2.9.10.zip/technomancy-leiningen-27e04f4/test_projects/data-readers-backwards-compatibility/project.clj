(defproject bug "bug"
  :dependencies [[org.clojure/clojure "1.8.0"]
                 [org.flatland/ordered "1.5.6"]])
