(ns leiningen.one-or-two "Dummy task for tests")

(defn one-or-two
  "Dummy task for tests"
  ([project one])
  ([project one two]))
