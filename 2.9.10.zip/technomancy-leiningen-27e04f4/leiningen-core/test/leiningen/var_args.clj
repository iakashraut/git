(ns leiningen.var-args "Dummy task for tests.")

(defn var-args [project & args]
  (println "a dummy task for tests."))
