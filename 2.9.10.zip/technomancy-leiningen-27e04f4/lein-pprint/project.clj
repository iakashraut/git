(defproject lein-pprint "1.3.2"
  :description "Pretty-print a representation of the project map."
  :url "https://codeberg.org/leiningen/leiningen"
  :license {:name "Eclipse Public License"
            :url "http://www.eclipse.org/legal/epl-v10.html"}
  :eval-in-leiningen true)
